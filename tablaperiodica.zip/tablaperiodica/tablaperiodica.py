import tkinter as tk
from tkinter import font as tkFont

class TablaPeriodicaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Tabla Periódica Interactiva")
        self.root.configure(bg="#eaf2f8") 


        # --- DATOS DE LOS ELEMENTOS ---
        # (Num Atómico, Símbolo, Nombre, Masa Atómica, Fila, Columna, Dato Curioso)
        self.elementos = [
            (1, "H", "Hidrógeno", 1.008, 1, 1, "Es el elemento más abundante del universo, constituye el 75% de su masa."),
            (2, "He", "Helio", 4.0026, 1, 18, "Es el único elemento que no se solidifica a presión atmosférica, sin importar cuán baja sea la temperatura."),
            (3, "Li", "Litio", 6.94, 2, 1, "Es el metal más ligero y menos denso, puede flotar en el agua."),
            (4, "Be", "Berilio", 9.0122, 2, 2, "Se utiliza en aleaciones para espejos de telescopios espaciales por su rigidez y ligereza."),
            (5, "B", "Boro", 10.81, 2, 13, "En forma de borosilicato, se usa para fabricar vidrio Pyrex, resistente a cambios bruscos de temperatura."),
            (6, "C", "Carbono", 12.011, 2, 14, "Es la base de toda la vida en la Tierra y puede formar más compuestos que cualquier otro elemento."),
            (7, "N", "Nitrógeno", 14.007, 2, 15, "Compone aproximadamente el 78% del aire que respiramos."),
            (8, "O", "Oxígeno", 15.999, 2, 16, "Es el tercer elemento más abundante del universo, después del hidrógeno y el helio."),
            (9, "F", "Flúor", 18.998, 2, 17, "Es el elemento más electronegativo y reactivo de todos."),
            (10, "Ne", "Neón", 20.180, 2, 18, "Brilla con una luz rojiza-anaranjada intensa cuando se utiliza en letreros luminosos."),
            (11, "Na", "Sodio", 22.990, 3, 1, "Reacciona violentamente con el agua, pudiendo causar explosiones."),
            (12, "Mg", "Magnesio", 24.305, 3, 2, "Produce una luz blanca y brillante al quemarse, por eso se usaba en los flashes de las cámaras antiguas."),
            (13, "Al", "Aluminio", 26.982, 3, 13, "Es el metal más abundante en la corteza terrestre."),
            (14, "Si", "Silicio", 28.085, 3, 14, "Es el componente principal de la arena y el cuarzo, y es fundamental para la industria electrónica (chips)."),
            (15, "P", "Fósforo", 30.974, 3, 15, "Fue el primer elemento en ser descubierto químicamente, en 1669, a partir de la orina."),
            (16, "S", "Azufre", 32.06, 3, 16, "Se le conoce desde la antigüedad y tiene un olor característico a huevos podridos en algunos de sus compuestos."),
            (17, "Cl", "Cloro", 35.45, 3, 17, "Fue utilizado como arma química (gas cloro) en la Primera Guerra Mundial."),
            (18, "Ar", "Argón", 39.948, 3, 18, "Se utiliza en el interior de las bombillas incandescentes para evitar que el filamento se queme."),
            (19, "K", "Potasio", 39.098, 4, 1, "Es un electrolito esencial para el funcionamiento del cuerpo humano, vital para la función nerviosa y muscular."),
            (20, "Ca", "Calcio", 40.078, 4, 2, "Es el mineral más abundante en el cuerpo humano, esencial para huesos y dientes."),
            (21, "Sc", "Escandio", 44.956, 4, 3, "Se añade al aluminio para crear aleaciones ligeras pero muy resistentes, usadas en la industria aeroespacial."),
            (22, "Ti", "Titanio", 47.867, 4, 4, "Tiene la mayor relación resistencia-peso de todos los metales y es altamente resistente a la corrosión."),
            (23, "V", "Vanadio", 50.942, 4, 5, "Se añade al acero para hacerlo más fuerte y resistente a los golpes, como en las herramientas."),
            (24, "Cr", "Cromo", 51.996, 4, 6, "Se utiliza para el cromado, que proporciona un acabado brillante y resistente a la corrosión en los metales."),
            (25, "Mn", "Manganeso", 54.938, 4, 7, "Es esencial para la producción de acero inoxidable, ya que previene la oxidación."),
            (26, "Fe", "Hierro", 55.845, 4, 8, "Es el núcleo de la molécula de hemoglobina, que transporta el oxígeno en la sangre."),
            (27, "Co", "Cobalto", 58.933, 4, 9, "Se usa para crear un pigmento azul intenso (azul cobalto) utilizado en vidrios y cerámicas durante siglos."),
            (28, "Ni", "Níquel", 58.693, 4, 10, "Es uno de los cuatro elementos que son ferromagnéticos a temperatura ambiente (junto con Fe, Co y Gd)."),
            (29, "Cu", "Cobre", 63.546, 4, 11, "Fue el primer metal manipulado por el ser humano, dando fin a la Edad de Piedra."),
            (30, "Zn", "Zinc", 65.38, 4, 12, "El latón es una aleación de cobre y zinc."),
            (31, "Ga", "Galio", 69.723, 4, 13, "Es un metal que se derrite en la mano, ya que su punto de fusión es de solo 29.7°C."),
            (32, "Ge", "Germanio", 72.630, 4, 14, "Es transparente a la luz infrarroja, por lo que se usa en lentes de cámaras térmicas."),
            (33, "As", "Arsénico", 74.922, 4, 15, "A pesar de ser tóxico, fue históricamente utilizado en medicina y como pigmento (Verde de París)."),
            (34, "Se", "Selenio", 78.971, 4, 16, "Su conductividad eléctrica aumenta con la exposición a la luz, propiedad usada en fotocélulas."),
            (35, "Br", "Bromo", 79.904, 4, 17, "Es uno de los dos únicos elementos que son líquidos a temperatura ambiente (el otro es el mercurio)."),
            (36, "Kr", "Kriptón", 83.798, 4, 18, "Su nombre viene del griego 'kryptos' (oculto), y se usa en flashes de alta velocidad para fotografía."),
            (37, "Rb", "Rubidio", 85.468, 5, 1, "Es tan reactivo que puede encenderse espontáneamente en el aire."),
            (38, "Sr", "Estroncio", 87.62, 5, 2, "Proporciona el color rojo intenso característico de los fuegos artificiales."),
            (39, "Y", "Itrio", 88.906, 5, 3, "Fue el primero de varios elementos descubiertos en Ytterby, un pueblo de Suecia."),
            (40, "Zr", "Zirconio", 91.224, 5, 4, "La zirconia cúbica es una imitación de diamante muy popular y económica."),
            (41, "Nb", "Niobio", 92.906, 5, 5, "Se usa en aleaciones para los motores de cohetes y jets por su resistencia a altas temperaturas."),
            (42, "Mo", "Molibdeno", 95.96, 5, 6, "Es un nutriente esencial para casi todos los organismos, aunque en cantidades muy pequeñas."),
            (43, "Tc", "Tecnecio", 98, 5, 7, "Es el elemento más ligero que no tiene isótopos estables; todo es radiactivo."),
            (44, "Ru", "Rutenio", 101.07, 5, 8, "Se usa para endurecer el platino y el paladio en aleaciones para contactos eléctricos."),
            (45, "Rh", "Rodio", 102.91, 5, 9, "Es uno de los metales preciosos más raros y valiosos, superando a menudo el precio del oro."),
            (46, "Pd", "Paladio", 106.42, 5, 10, "Tiene la capacidad de absorber hasta 900 veces su propio volumen de hidrógeno gaseoso."),
            (47, "Ag", "Plata", 107.87, 5, 11, "Es el mejor conductor de electricidad y calor de todos los metales."),
            (48, "Cd", "Cadmio", 112.41, 5, 12, "Se utiliza en las barras de control de los reactores nucleares para absorber neutrones."),
            (49, "In", "Indio", 114.82, 5, 13, "Produce un 'grito' agudo cuando se dobla, debido a la fricción de sus cristales internos."),
            (50, "Sn", "Estaño", 118.71, 5, 14, "Una de sus aleaciones, el bronce (con cobre), dio nombre a toda una era de la humanidad."),
            (51, "Sb", "Antimonio", 121.76, 5, 15, "Los antiguos egipcios lo usaban como kohl para delinear los ojos."),
            (52, "Te", "Telurio", 127.60, 5, 16, "En su forma elemental, tiene un olor a ajo muy penetrante y desagradable."),
            (53, "I", "Yodo", 126.90, 5, 17, "Es esencial para la producción de hormonas tiroideas en el cuerpo humano."),
            (54, "Xe", "Xenón", 131.29, 5, 18, "Se utiliza en faros de coches de alta gama por su luz azul-blanca, brillante y potente."),
            (55, "Cs", "Cesio", 132.91, 6, 1, "Se utiliza en los relojes atómicos, los instrumentos de medición de tiempo más precisos del mundo."),
            (56, "Ba", "Bario", 137.33, 6, 2, "Proporciona el color verde en los fuegos artificiales."),
            (57, "La", "Lantano", 138.91, 9, 3, "Se encuentra en las lentes de cámaras y telescopios de alta calidad."),
            (58, "Ce", "Cerio", 140.12, 9, 4, "Es el componente principal de la 'piedra' de los encendedores comunes."),
            (59, "Pr", "Praseodimio", 140.91, 9, 5, "Crea un vidrio de color amarillo verdoso (vidrio de didimio) usado en las gafas de protección de los soldadores."),
            (60, "Nd", "Neodimio", 144.24, 9, 6, "Forma parte de los imanes permanentes más potentes conocidos, usados en auriculares y motores eléctricos."),
            (61, "Pm", "Prometio", 145, 9, 7, "Es extremadamente raro y se usa en pinturas luminosas para relojes y en baterías nucleares."),
            (62, "Sm", "Samario", 150.36, 9, 8, "Sus imanes son muy resistentes a las altas temperaturas, superando a los de neodimio en ese aspecto."),
            (63, "Eu", "Europio", 151.96, 9, 9, "Se usaba en los tubos de rayos catódicos de los televisores antiguos para producir el color rojo."),
            (64, "Gd", "Gadolinio", 157.25, 9, 10, "Se utiliza como agente de contraste en las resonancias magnéticas para mejorar la visibilidad de las imágenes."),
            (65, "Tb", "Terbio", 158.93, 9, 11, "Se usa para producir el color verde en pantallas de plasma y fluorescentes."),
            (66, "Dy", "Disprosio", 162.50, 9, 12, "Se añade a los imanes de neodimio para ayudarles a mantener su magnetismo a altas temperaturas."),
            (67, "Ho", "Holmio", 164.93, 9, 13, "Tiene la mayor fuerza magnética de todos los elementos."),
            (68, "Er", "Erbio", 167.26, 9, 14, "Se utiliza como colorante rosa en vidrios y cerámicas."),
            (69, "Tm", "Tulio", 168.93, 9, 15, "Es el lantánido más raro de todos y se usa en algunos láseres quirúrgicos."),
            (70, "Yb", "Iterbio", 173.05, 9, 16, "Se utiliza en algunos relojes atómicos y como fuente de rayos gamma portátiles."),
            (71, "Lu", "Lutecio", 174.97, 9, 17, "Es el elemento lantánido más denso y duro."),
            (72, "Hf", "Hafnio", 178.49, 6, 4, "Es tan similar al zirconio que es muy difícil separarlos; se encuentra siempre junto a él en la naturaleza."),
            (73, "Ta", "Tantalio", 180.95, 6, 5, "Es extremadamente resistente a la corrosión y se usa para implantes quirúrgicos porque no reacciona con el cuerpo."),
            (74, "W", "Wolframio", 183.84, 6, 6, "Tiene el punto de fusión más alto de todos los metales, por eso se usaba en los filamentos de las bombillas."),
            (75, "Re", "Renio", 186.21, 6, 7, "Es uno de los metales más densos y tiene el tercer punto de fusión más alto."),
            (76, "Os", "Osmio", 190.23, 6, 8, "Es el elemento natural más denso de todos. Una botella de refresco llena de osmio pesaría más de 100 kg."),
            (77, "Ir", "Iridio", 192.22, 6, 9, "Es el segundo elemento más denso y el metal más resistente a la corrosión. Se cree que la capa de iridio en la corteza terrestre es evidencia del impacto de un asteroide que extinguió a los dinosaurios."),
            (78, "Pt", "Platino", 195.08, 6, 10, "Es un catalizador muy importante, usado en los convertidores catalíticos de los coches para reducir la contaminación."),
            (79, "Au", "Oro", 196.97, 6, 11, "Es tan maleable que una onza (28 gramos) se puede estirar en un alambre de 80 kilómetros de largo."),
            (80, "Hg", "Mercurio", 200.59, 6, 12, "Es el único metal que es líquido a temperatura ambiente."),
            (81, "Tl", "Talio", 204.38, 6, 13, "Es extremadamente tóxico y fue conocido como el 'veneno de los envenenadores' por ser inodoro e insípido."),
            (82, "Pb", "Plomo", 208.98, 6, 14, "Los romanos lo usaban extensamente para tuberías de agua y recipientes, lo que pudo causar envenenamiento crónico."),
            (83, "Bi", "Bismuto", 208.98, 6, 15, "Es el ingrediente activo en medicamentos para el malestar estomacal como el Pepto-Bismol."),
            (84, "Po", "Polonio", 209, 6, 16, "Fue descubierto por Marie Curie y nombrado en honor a su país natal, Polonia. Es extremadamente radiactivo."),
            (85, "At", "Astato", 210, 6, 17, "Es el elemento natural más raro de la Tierra; se estima que hay menos de 30 gramos en toda la corteza terrestre en un momento dado."),
            (86, "Rn", "Radón", 222, 6, 18, "Es un gas radiactivo que emana del suelo y puede acumularse en los sótanos, siendo una causa de cáncer de pulmón."),
            (87, "Fr", "Francio", 223, 7, 1, "Es el segundo elemento natural más raro (después del Astato) y es extremadamente inestable."),
            (88, "Ra", "Radio", 226, 7, 2, "También descubierto por Marie Curie, se usó en pinturas luminiscentes para relojes hasta que se descubrieron sus peligros."),
            (89, "Ac", "Actinio", 227, 10, 3, "Brilla en la oscuridad con una misteriosa luz azul debido a su intensa radiactividad."),
            (90, "Th", "Torio", 232.04, 10, 4, "Se ha investigado como un combustible nuclear más seguro y abundante que el uranio."),
            (91, "Pa", "Protactinio", 231.04, 10, 5, "Es uno de los elementos naturales más raros y caros."),
            (92, "U", "Uranio", 238.03, 10, 6, "Es el combustible principal para los reactores nucleares y las armas nucleares."),
            (93, "Np", "Neptunio", 237, 10, 7, "Fue el primer elemento transuránico (más pesado que el uranio) en ser sintetizado."),
            (94, "Pu", "Plutonio", 244, 10, 8, "Se utiliza como combustible en algunos reactores nucleares y es un componente clave en las armas nucleares modernas."),
            (95, "Am", "Americio", 243, 10, 9, "Se utiliza en la mayoría de los detectores de humo domésticos."),
            (96, "Cm", "Curio", 247, 10, 10, "Nombrado en honor a Marie y Pierre Curie, es tan radiactivo que brilla en la oscuridad."),
            (97, "Bk", "Berkelio", 247, 10, 11, "Nombrado en honor a la ciudad de Berkeley, California, donde fue descubierto."),
            (98, "Cf", "Californio", 251, 10, 12, "Es uno de los elementos más caros del mundo, con un precio de millones de dólares por microgramo."),
            (99, "Es", "Einstenio", 252, 10, 13, "Fue descubierto en los escombros de la primera explosión de una bomba de hidrógeno."),
            (100, "Fm", "Fermio", 257, 10, 14, "Nombrado en honor a Enrico Fermi, es el elemento más pesado que se puede crear mediante bombardeo de neutrones."),
            (101, "Md", "Mendelevio", 258, 10, 15, "Nombrado en honor a Dmitri Mendeléyev, el padre de la tabla periódica."),
            (102, "No", "Nobelio", 259, 10, 16, "Nombrado en honor a Alfred Nobel, inventor de la dinamita y creador de los Premios Nobel."),
            (103, "Lr", "Lawrencio", 262, 10, 17, "Nombrado en honor a Ernest Lawrence, inventor del ciclotrón."),
            (104, "Rf", "Rutherfordio", 267, 7, 4, "Nombrado en honor a Ernest Rutherford, el padre de la física nuclear."),
            (105, "Db", "Dubnio", 268, 7, 5, "Nombrado en honor al centro de investigación nuclear de Dubná, en Rusia."),
            (106, "Sg", "Seaborgio", 271, 7, 6, "Nombrado en honor a Glenn T. Seaborg, el único científico que tuvo un elemento nombrado en su honor mientras aún estaba vivo."),
            (107, "Bh", "Bohrio", 272, 7, 7, "Nombrado en honor a Niels Bohr, uno de los padres de la mecánica cuántica."),
            (108, "Hs", "Hasio", 270, 7, 8, "Nombrado en honor al estado alemán de Hesse (Hassia en latín), donde se encuentra el laboratorio que lo descubrió."),
            (109, "Mt", "Meitnerio", 276, 7, 9, "Nombrado en honor a Lise Meitner, una física pionera en el campo de la fisión nuclear."),
            (110, "Ds", "Darmstatio", 281, 7, 10, "Nombrado en honor a la ciudad de Darmstadt, Alemania, sede del instituto donde fue creado."),
            (111, "Rg", "Roentgenio", 280, 7, 11, "Nombrado en honor a Wilhelm Conrad Röntgen, descubridor de los rayos X."),
            (112, "Cn", "Copernicio", 285, 7, 12, "Nombrado en honor a Nicolás Copérnico, el astrónomo que propuso el modelo heliocéntrico."),
            (113, "Nh", "Nihonio", 284, 7, 13, "Su nombre proviene de la palabra japonesa 'Nihon' (Japón), donde fue descubierto."),
            (114, "Fl", "Flerovio", 289, 7, 14, "Nombrado en honor al Laboratorio Flerov de Reacciones Nucleares en Dubná, Rusia."),
            (115, "Mc", "Moscovio", 288, 7, 15, "Nombrado en honor a la región de Moscú, donde se encuentra el instituto que colaboró en su descubrimiento."),
            (116, "Lv", "Livermorio", 293, 7, 16, "Nombrado en honor al Laboratorio Nacional Lawrence Livermore en California."),
            (117, "Ts", "Teneso", 294, 7, 17, "Nombrado en honor al estado de Tennessee, reconocido por su investigación en química."),
            (118, "Og", "Oganesón", 294, 7, 18, "Nombrado en honor a Yuri Oganessian, un físico nuclear pionero en la investigación de elementos superpesados.")
        ]
        
        # --- COLORES Y CATEGORÍAS ---
        self.colores = {
            "Gas noble": "#D7BDE2", "Alcalino": "#F5B7B1", "Alcalinotérreo": "#FAD7A0",
            "Metaloide": "#A9DFBF", "No metal": "#A3E4D7", "Halógeno": "#A9CCE3",
            "Metal de transición": "#AED6F1", "Metal del bloque p": "#D5DBDB",
            "Lantánido": "#F5CBA7", "Actínido": "#E6B0AA", "Propiedades desconocidas": "#FFFFFF"
        }
        
        self.categorias = {
            1: "No metal", 2: "Gas noble", 3: "Alcalino", 4: "Alcalinotérreo",
            5: "Metaloide", 6: "No metal", 7: "No metal", 8: "No metal", 9: "Halógeno", 10: "Gas noble",
            11: "Alcalino", 12: "Alcalinotérreo", 13: "Metal del bloque p", 14: "Metaloide", 15: "No metal",
            16: "No metal", 17: "Halógeno", 18: "Gas noble", 19: "Alcalino", 20: "Alcalinotérreo",
            21: "Metal de transición", 22: "Metal de transición", 23: "Metal de transición", 24: "Metal de transición",
            25: "Metal de transición", 26: "Metal de transición", 27: "Metal de transición", 28: "Metal de transición",
            29: "Metal de transición", 30: "Metal de transición", 31: "Metal del bloque p", 32: "Metaloide",
            33: "Metaloide", 34: "No metal", 35: "Halógeno", 36: "Gas noble", 37: "Alcalino",
            38: "Alcalinotérreo", 39: "Metal de transición", 40: "Metal de transición", 41: "Metal de transición",
            42: "Metal de transición", 43: "Metal de transición", 44: "Metal de transición", 45: "Metal de transición",
            46: "Metal de transición", 47: "Metal de transición", 48: "Metal de transición", 49: "Metal del bloque p",
            50: "Metal del bloque p", 51: "Metaloide", 52: "Metaloide", 53: "Halógeno", 54: "Gas noble",
            55: "Alcalino", 56: "Alcalinotérreo", 57: "Lantánido", 58: "Lantánido",
            59: "Lantánido", 60: "Lantánido", 61: "Lantánido", 62: "Lantánido", 63: "Lantánido",
            64: "Lantánido", 65: "Lantánido", 66: "Lantánido", 67: "Lantánido", 68: "Lantánido",
            69: "Lantánido", 70: "Lantánido", 71: "Lantánido", 72: "Metal de transición", 73: "Metal de transición",
            74: "Metal de transición", 75: "Metal de transición", 76: "Metal de transición", 77: "Metal de transición",
            78: "Metal de transición", 79: "Metal de transición", 80: "Metal de transición", 81: "Metal del bloque p",
            82: "Metal del bloque p", 83: "Metal del bloque p", 84: "Metal del bloque p", 85: "Halógeno",
            86: "Gas noble", 87: "Alcalino", 88: "Alcalinotérreo", 89: "Actínido",
            90: "Actínido", 91: "Actínido", 92: "Actínido", 93: "Actínido", 94: "Actínido",
            95: "Actínido", 96: "Actínido", 97: "Actínido", 98: "Actínido", 99: "Actínido",
            100: "Actínido", 101: "Actínido", 102: "Actínido", 103: "Actínido", 104: "Metal de transición",
            105: "Metal de transición", 106: "Metal de transición", 107: "Metal de transición", 108: "Metal de transición",
            109: "Metal de transición", 110: "Metal de transición", 111: "Metal de transición", 112: "Metal de transición",
            113: "Propiedades desconocidas", 114: "Propiedades desconocidas", 115: "Propiedades desconocidas", 116: "Propiedades desconocidas",
            117: "Propiedades desconocidas", 118: "Propiedades desconocidas"
        }
        
        # --- FUENTES Y ESTILOS ---
        self.fuente_simbolo = tkFont.Font(family="Segoe UI", size=12, weight="bold")
        self.fuente_numero = tkFont.Font(family="Segoe UI", size=8)
        self.fuente_info = tkFont.Font(family="Segoe UI", size=10)
        self.fuente_titulo_info = tkFont.Font(family="Segoe UI", size=14, weight="bold")

        # --- CONSTRUCCIÓN DE LA GUI ---
        # Contenedor principal
        main_frame = tk.Frame(root, bg="#eaf2f8")
        main_frame.pack(padx=10, pady=10, fill="both", expand=True)

        # Frame para la tabla
        self.frame_tabla = tk.Frame(main_frame, bg="#eaf2f8")
        self.frame_tabla.grid(row=0, column=0, padx=(0, 20))

        # Frame para la tarjeta de información
        self.frame_info = tk.Frame(main_frame, bg="#ffffff", bd=1, relief="solid")
        self.frame_info.grid(row=0, column=1, sticky="ns", ipadx=10, ipady=10)
        main_frame.grid_columnconfigure(1, weight=1)

        self.crear_tabla_periodica()
        self.crear_tarjeta_info()
        self.crear_leyenda()
        
        # Mostrar info del Hidrógeno al iniciar
        self.mostrar_info(self.elementos[0])

    def crear_tabla_periodica(self):
        for data_elemento in self.elementos:
            num_atomico, simbolo, _, _, fila, columna, _ = data_elemento
            
            categoria = self.categorias.get(num_atomico, "Propiedades desconocidas")
            color_fondo = self.colores.get(categoria, "#FFFFFF")
            color_hover = self.get_hover_color(color_fondo)

            btn = tk.Frame(self.frame_tabla, bg=color_fondo, width=60, height=60, bd=1, relief="raised")
            btn.grid(row=fila, column=columna, padx=1, pady=1)
            btn.propagate(False)

            lbl_num = tk.Label(btn, text=str(num_atomico), bg=color_fondo, font=self.fuente_numero)
            lbl_num.pack(anchor="nw", padx=3, pady=1)

            lbl_simbolo = tk.Label(btn, text=simbolo, bg=color_fondo, font=self.fuente_simbolo)
            lbl_simbolo.pack(expand=True)
            
            widgets = [btn, lbl_num, lbl_simbolo]
            
            # Eventos (clic y hover)
            for widget in widgets:
                widget.bind("<Button-1>", lambda e, d=data_elemento: self.mostrar_info(d))
                widget.bind("<Enter>", lambda e, w=widgets, c=color_hover: self.on_enter(w, c))
                widget.bind("<Leave>", lambda e, w=widgets, c=color_fondo: self.on_leave(w, c))

    def crear_tarjeta_info(self):
        # Frame interno para padding
        inner_info_frame = tk.Frame(self.frame_info, bg="#ffffff")
        inner_info_frame.pack(padx=15, pady=15, fill="both", expand=True)

        self.lbl_info_num_atomico = tk.Label(inner_info_frame, text="", bg="#ffffff", font=self.fuente_numero, anchor="w")
        self.lbl_info_num_atomico.pack(fill="x")

        self.lbl_info_simbolo = tk.Label(inner_info_frame, text="", bg="#ffffff", font=tkFont.Font(family="Segoe UI", size=48, weight="bold"), anchor="w")
        self.lbl_info_simbolo.pack(fill="x", pady=(0, 5))
        
        self.lbl_info_nombre = tk.Label(inner_info_frame, text="", bg="#ffffff", font=self.fuente_titulo_info, anchor="w")
        self.lbl_info_nombre.pack(fill="x")

        separator = tk.Frame(inner_info_frame, bg="#e0e0e0", height=1)
        separator.pack(fill="x", pady=10)

        self.lbl_info_categoria = tk.Label(inner_info_frame, text="", bg="#ffffff", font=self.fuente_info, anchor="w", justify="left")
        self.lbl_info_categoria.pack(fill="x", pady=2)
        
        self.lbl_info_masa = tk.Label(inner_info_frame, text="", bg="#ffffff", font=self.fuente_info, anchor="w", justify="left")
        self.lbl_info_masa.pack(fill="x", pady=2)

        separator2 = tk.Frame(inner_info_frame, bg="#e0e0e0", height=1)
        separator2.pack(fill="x", pady=10)
        
        lbl_titulo_dato = tk.Label(inner_info_frame, text="Dato Curioso:", bg="#ffffff", font=tkFont.Font(family="Segoe UI", size=10, weight="bold"), anchor="w")
        lbl_titulo_dato.pack(fill="x", pady=(5,2))

        self.lbl_info_dato = tk.Label(inner_info_frame, text="", bg="#ffffff", font=self.fuente_info, wraplength=250, justify="left", anchor="w")
        self.lbl_info_dato.pack(fill="x")

    def crear_leyenda(self):
        frame_leyenda = tk.Frame(self.root, bg="#eaf2f8")
        frame_leyenda.pack(fill="x", padx=10, pady=(0, 10))

        col = 0
        for categoria, color in self.colores.items():
            frame_item = tk.Frame(frame_leyenda, bg="#eaf2f8")
            frame_item.pack(side="left", padx=10, pady=2)
            
            cuadro_color = tk.Frame(frame_item, bg=color, width=15, height=15, bd=1, relief="solid")
            cuadro_color.pack(side="left")

            lbl_texto = tk.Label(frame_item, text=categoria, bg="#eaf2f8", font=("Segoe UI", 8))
            lbl_texto.pack(side="left", padx=5)

    def mostrar_info(self, data_elemento):
        num_atomico, simbolo, nombre, masa, _, _, dato = data_elemento
        categoria = self.categorias.get(num_atomico, "Desconocida")
        
        self.lbl_info_num_atomico.config(text=f"{num_atomico}")
        self.lbl_info_simbolo.config(text=simbolo)
        self.lbl_info_nombre.config(text=nombre)
        self.lbl_info_categoria.config(text=f"Categoría: {categoria}")
        self.lbl_info_masa.config(text=f"Masa atómica: {masa}")
        self.lbl_info_dato.config(text=dato)
        
        color_fondo = self.colores.get(categoria, "#FFFFFF")
        self.lbl_info_nombre.config(fg=self.get_hover_color(color_fondo))


    # --- FUNCIONES DE EVENTOS ---
    def on_enter(self, widgets, color):
        for widget in widgets:
            widget.configure(bg=color)

    def on_leave(self, widgets, color):
        for widget in widgets:
            widget.configure(bg=color)
            
    def get_hover_color(self, hex_color):
        hex_color = hex_color.lstrip('#')
        rgb = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        darker_rgb = tuple(max(0, c - 20) for c in rgb)
        return f"#{darker_rgb[0]:02x}{darker_rgb[1]:02x}{darker_rgb[2]:02x}"


if __name__ == "__main__":
    root = tk.Tk()
    app = TablaPeriodicaApp(root)
    root.mainloop()